import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist, PoseStamped
from sensor_msgs.msg import LaserScan
from nav_msgs.msg import OccupancyGrid, Path, Odometry
import numpy as np
import heapq
import math
import time

class AStarPathfinder(Node):
    def __init__(self):
        super().__init__('pathfinder_node')
        
        # Publishers
        self.cmd_pub = self.create_publisher(Twist, '/cmd_vel', 10)
        self.path_pub = self.create_publisher(Path, '/planned_path', 10)
        
        # Subscribers
        self.scan_sub = self.create_subscription(LaserScan, '/scan', self.scan_callback, 10)
        self.odom_sub = self.create_subscription(Odometry, '/odom', self.odom_callback, 10)
        self.goal_sub = self.create_subscription(PoseStamped, '/goal_pose', self.goal_callback, 10)
        
        # Variables de position
        self.robot_x = 0.0
        self.robot_y = 0.0
        self.robot_yaw = 0.0
        
        # Variables
        self.current_scan = None
        self.goal_pose = None
        self.planned_path = []
        self.current_target_index = 0
        
        # **NOUVEAUX PARAMÈTRES ANTI-OSCILLATIONS**
        self.path_lookahead = 3
        self.min_turn_angle = 0.05
        self.target_tolerance = 0.3
        self.direct_goal_distance = 2.0
        
        # **VARIABLES POUR ÉVITEMENT STABLE**
        self.avoidance_mode = False
        self.avoidance_direction = 0
        self.avoidance_start_time = 0
        self.avoidance_timeout = 3.0
        self.last_position = (0.0, 0.0)
        self.stuck_counter = 0
        self.stuck_threshold = 10
        self.min_movement = 0.05
        
        # **NOUVELLES VARIABLES ANTI-RECALCUL**
        self.last_replan_time = 0
        self.replan_interval = 5.0  # Augmenté à 5 secondes
        self.path_validity_time = 10.0  # Un path reste valide 10 secondes
        self.path_creation_time = 0
        self.last_target_angle = None
        self.angle_change_threshold = 0.8  # ~45 degrés max de changement
        self.path_progress_threshold = 0.5  # Distance min parcourue avant replan
        self.last_path_distance = 0
        self.consecutive_stuck_count = 0
        self.force_replan_threshold = 3  # Forcer replan après 3 blocages consécutifs
        
        # **PARAMÈTRES POUR TAILLE DU ROBOT**
        self.robot_radius = 0.40
        self.safety_margin = 0.0
        self.total_robot_size = self.robot_radius + self.safety_margin
        
        # Créer une grille d'occupation basée sur le laser
        self.grid_size = 200
        self.grid_resolution = 0.1
        self.occupancy_grid = np.zeros((self.grid_size, self.grid_size))
        
        # Timer pour le contrôle
        self.control_timer = self.create_timer(0.2, self.control_loop)
        
        self.get_logger().info(f'A* Pathfinder Node avec stabilisation démarré!')
        
    def odom_callback(self, msg):
        """Met à jour la position du robot"""
        self.robot_x = msg.pose.pose.position.x
        self.robot_y = msg.pose.pose.position.y
        
        # Convertir quaternion en yaw
        quat = msg.pose.pose.orientation
        self.robot_yaw = math.atan2(
            2 * (quat.w * quat.z + quat.x * quat.y),
            1 - 2 * (quat.y * quat.y + quat.z * quat.z)
        )
        
    def scan_callback(self, msg):
        """Traite les données du laser"""
        self.current_scan = msg
        self.update_occupancy_grid(msg)
        
    def update_occupancy_grid(self, scan_msg):
        """Met à jour la grille d'occupation avec inflation adaptée à la taille du robot"""
        # Réinitialiser la grille
        self.occupancy_grid = np.zeros((self.grid_size, self.grid_size))
        
        angle_min = scan_msg.angle_min
        angle_increment = scan_msg.angle_increment
        
        # Calculer le rayon d'inflation en cellules de grille
        inflation_radius = int(self.total_robot_size / self.grid_resolution)
        
        # Créer une grille temporaire pour les obstacles détectés
        temp_grid = np.zeros((self.grid_size, self.grid_size))
        
        for i, distance in enumerate(scan_msg.ranges):
            if distance < scan_msg.range_min or distance > scan_msg.range_max:
                continue
                
            if distance > 8.0:
                continue
                
            laser_angle = angle_min + i * angle_increment
            global_angle = laser_angle + self.robot_yaw
            
            obs_x = self.robot_x + distance * math.cos(global_angle)
            obs_y = self.robot_y + distance * math.sin(global_angle)
            
            grid_x = int((obs_x + 10.0) / self.grid_resolution)
            grid_y = int((obs_y + 10.0) / self.grid_resolution)
            
            if 0 <= grid_x < self.grid_size and 0 <= grid_y < self.grid_size:
                temp_grid[grid_y, grid_x] = 1
        
        # Appliquer l'inflation basée sur la taille réelle du robot
        for y in range(self.grid_size):
            for x in range(self.grid_size):
                if temp_grid[y, x] == 1:
                    for dy in range(-inflation_radius, inflation_radius + 1):
                        for dx in range(-inflation_radius, inflation_radius + 1):
                            distance = math.sqrt(dx*dx + dy*dy) * self.grid_resolution
                            if distance <= self.total_robot_size:
                                nx, ny = x + dx, y + dy
                                if 0 <= nx < self.grid_size and 0 <= ny < self.grid_size:
                                    self.occupancy_grid[ny, nx] = 1
    
    def should_replan(self):
        """Décide intelligemment si on doit replanifier"""
        current_time = time.time()
        
        # Ne pas replanifier trop souvent
        if (current_time - self.last_replan_time) < self.replan_interval:
            return False
            
        # Si le path est encore récent et qu'on progresse, ne pas replanifier
        if (current_time - self.path_creation_time) < self.path_validity_time:
            # Vérifier si on progresse sur le chemin
            if self.planned_path and self.current_target_index > 0:
                progress = self.current_target_index / len(self.planned_path)
                if progress > 0.2:  # Si on a fait plus de 20% du chemin
                    return False
        
        # Si on est bloqué plusieurs fois de suite, forcer le replan
        if self.consecutive_stuck_count >= self.force_replan_threshold:
            self.get_logger().warn(f'Blocage répété ({self.consecutive_stuck_count}x) - Forçage du replan')
            return True
            
        # Vérifier si le chemin est vraiment bloqué
        if self.is_path_significantly_blocked():
            return True
            
        return False
    
    def is_path_significantly_blocked(self):
        """Vérifie si le chemin est significativement bloqué (pas juste un petit obstacle)"""
        if not self.planned_path or self.current_target_index >= len(self.planned_path):
            return False
            
        blocked_points = 0
        check_points = min(5, len(self.planned_path) - self.current_target_index)
        
        for i in range(self.current_target_index, self.current_target_index + check_points):
            if i < len(self.planned_path):
                target_x, target_y = self.planned_path[i]
                if not self.can_go_direct(self.robot_x, self.robot_y, target_x, target_y):
                    blocked_points += 1
                    
        # Le chemin est significativement bloqué si plus de 60% des points sont bloqués
        return blocked_points > check_points * 0.6
    
    def can_go_direct(self, start_x, start_y, goal_x, goal_y):
        """Vérifie si on peut aller directement au goal"""
        steps = int(math.sqrt((goal_x - start_x)**2 + (goal_y - start_y)**2) / self.grid_resolution)
        if steps == 0:
            return True
            
        for i in range(steps + 1):
            t = i / steps if steps > 0 else 0
            check_x = int((start_x + t * (goal_x - start_x) + 10.0) / self.grid_resolution)
            check_y = int((start_y + t * (goal_y - start_y) + 10.0) / self.grid_resolution)
            
            if (0 <= check_x < self.grid_size and 0 <= check_y < self.grid_size):
                if self.occupancy_grid[check_y, check_x] == 1:
                    return False
        return True
    
    def detect_if_stuck(self):
        """Détecte si le robot est bloqué"""
        current_pos = (self.robot_x, self.robot_y)
        distance_moved = math.sqrt(
            (current_pos[0] - self.last_position[0])**2 + 
            (current_pos[1] - self.last_position[1])**2
        )
        
        if distance_moved < self.min_movement:
            self.stuck_counter += 1
            if self.stuck_counter > self.stuck_threshold:
                self.consecutive_stuck_count += 1
                return True
        else:
            self.stuck_counter = 0
            self.consecutive_stuck_count = 0
            
        self.last_position = current_pos
        return False
    
    def choose_avoidance_direction(self):
        """Choisit intelligemment la direction d'évitement"""
        if not self.current_scan:
            return 1
            
        ranges = self.current_scan.ranges
        n_ranges = len(ranges)
        
        left_ranges = ranges[n_ranges*3//4:n_ranges-1]
        right_ranges = ranges[1:n_ranges//4]
        
        left_space = np.mean([r for r in left_ranges if not math.isinf(r) and r > 0])
        right_space = np.mean([r for r in right_ranges if not math.isinf(r) and r > 0])
        
        if math.isnan(left_space):
            left_space = 0
        if math.isnan(right_space):
            right_space = 0
            
        if left_space > right_space:
            return 1  # Gauche
        else:
            return -1  # Droite
    
    def goal_callback(self, msg):
        """Reçoit un nouvel objectif"""
        self.goal_pose = msg
        self.avoidance_mode = False
        self.stuck_counter = 0
        self.consecutive_stuck_count = 0
        self.last_target_angle = None
        
        self.get_logger().info(f'Nouvel objectif: x={msg.pose.position.x:.2f}, y={msg.pose.position.y:.2f}')
        
        distance_to_goal = math.sqrt(
            (msg.pose.position.x - self.robot_x)**2 + 
            (msg.pose.position.y - self.robot_y)**2
        )
        
        if (distance_to_goal < self.direct_goal_distance and 
            self.can_go_direct(self.robot_x, self.robot_y, msg.pose.position.x, msg.pose.position.y)):
            
            self.get_logger().info('Chemin direct possible!')
            self.planned_path = [(msg.pose.position.x, msg.pose.position.y)]
            self.current_target_index = 0
            self.path_creation_time = time.time()
            self.publish_path()
        else:
            path = self.plan_path()
            if path:
                self.planned_path = path
                self.current_target_index = 0
                self.path_creation_time = time.time()
                self.last_replan_time = time.time()
                self.publish_path()
                self.get_logger().info(f'Chemin A* planifié avec {len(path)} points')
            else:
                self.get_logger().error('Impossible de planifier un chemin!')
    
    def plan_path(self):
        """Algorithme A* optimisé"""
        if not self.goal_pose:
            return None
            
        start_x = int((self.robot_x + 10.0) / self.grid_resolution)
        start_y = int((self.robot_y + 10.0) / self.grid_resolution)
        start = (start_x, start_y)
        
        goal_x = int((self.goal_pose.pose.position.x + 10.0) / self.grid_resolution)
        goal_y = int((self.goal_pose.pose.position.y + 10.0) / self.grid_resolution)
        goal = (goal_x, goal_y)
        
        # Vérifications
        if not (0 <= start_x < self.grid_size and 0 <= start_y < self.grid_size):
            return None
        if not (0 <= goal_x < self.grid_size and 0 <= goal_y < self.grid_size):
            return None
            
        # Trouver des positions libres si nécessaire
        if self.occupancy_grid[start_y, start_x] == 1:
            start = self.find_free_position(start_x, start_y)
            if not start:
                return None
                
        if self.occupancy_grid[goal_y, goal_x] == 1:
            goal = self.find_free_position(goal_x, goal_y)
            if not goal:
                return None
        
        return self.astar(start, goal)
    
    def find_free_position(self, x, y):
        """Trouve une position libre proche"""
        for radius in range(1, 10):
            for dx in range(-radius, radius + 1):
                for dy in range(-radius, radius + 1):
                    new_x, new_y = x + dx, y + dy
                    if (0 <= new_x < self.grid_size and 0 <= new_y < self.grid_size and 
                        self.occupancy_grid[new_y, new_x] == 0):
                        return (new_x, new_y)
        return None
    
    def astar(self, start, goal):
        """A* avec optimisations"""
        def heuristic(a, b):
            return math.sqrt((a[0] - b[0])**2 + (a[1] - b[1])**2)
        
        def get_neighbors(node):
            x, y = node
            neighbors = []
            for dx, dy in [(-1,-1), (-1,0), (-1,1), (0,-1), (0,1), (1,-1), (1,0), (1,1)]:
                nx, ny = x + dx, y + dy
                if (0 <= nx < self.grid_size and 0 <= ny < self.grid_size and 
                    self.occupancy_grid[ny, nx] == 0):
                    neighbors.append((nx, ny))
            return neighbors
        
        open_set = [(0, start)]
        came_from = {}
        g_score = {start: 0}
        f_score = {start: heuristic(start, goal)}
        closed_set = set()
        
        while open_set:
            current = heapq.heappop(open_set)[1]
            
            if current in closed_set:
                continue
            closed_set.add(current)
            
            if current == goal:
                path = []
                while current in came_from:
                    path.append(current)
                    current = came_from[current]
                path.append(start)
                path.reverse()
                
                simplified_path = self.simplify_path(path)
                
                world_path = []
                for x, y in simplified_path:
                    world_x = (x * self.grid_resolution) - 10.0
                    world_y = (y * self.grid_resolution) - 10.0
                    world_path.append((world_x, world_y))
                
                return world_path
            
            for neighbor in get_neighbors(current):
                if neighbor in closed_set:
                    continue
                    
                tentative_g_score = g_score[current] + heuristic(current, neighbor)
                
                if neighbor not in g_score or tentative_g_score < g_score[neighbor]:
                    came_from[neighbor] = current
                    g_score[neighbor] = tentative_g_score
                    f_score[neighbor] = tentative_g_score + heuristic(neighbor, goal)
                    heapq.heappush(open_set, (f_score[neighbor], neighbor))
        
        return None
    
    def simplify_path(self, path):
        """Simplifie le chemin en enlevant les points inutiles"""
        if len(path) < 3:
            return path
            
        simplified = [path[0]]
        i = 0
        
        while i < len(path) - 1:
            farthest = i + 1
            for j in range(i + 2, len(path)):
                if self.line_is_free(path[i], path[j]):
                    farthest = j
                else:
                    break
            
            simplified.append(path[farthest])
            i = farthest
            
        return simplified
    
    def line_is_free(self, start, end):
        """Vérifie si une ligne est libre d'obstacles"""
        x0, y0 = start
        x1, y1 = end
        
        dx = abs(x1 - x0)
        dy = abs(y1 - y0)
        steps = max(dx, dy)
        
        if steps == 0:
            return True
            
        x_inc = (x1 - x0) / steps
        y_inc = (y1 - y0) / steps
        
        for i in range(steps + 1):
            x = int(x0 + i * x_inc)
            y = int(y0 + i * y_inc)
            
            if 0 <= x < self.grid_size and 0 <= y < self.grid_size:
                if self.occupancy_grid[y, x] == 1:
                    return False
        return True
    
    def publish_path(self):
        """Publie le chemin pour RViz"""
        path_msg = Path()
        path_msg.header.frame_id = "odom"
        path_msg.header.stamp = self.get_clock().now().to_msg()
        
        for x, y in self.planned_path:
            pose = PoseStamped()
            pose.header.frame_id = "odom"
            pose.pose.position.x = x
            pose.pose.position.y = y
            pose.pose.position.z = 0.0
            pose.pose.orientation.w = 1.0
            path_msg.poses.append(pose)
        
        self.path_pub.publish(path_msg)
    
    def get_target_point(self):
        """Obtient le point cible avec stabilisation"""
        if not self.planned_path:
            return None
        
        # Ne jamais reculer dans le chemin
        for i in range(self.current_target_index, len(self.planned_path)):
            target_x, target_y = self.planned_path[i]
            distance = math.sqrt((target_x - self.robot_x)**2 + (target_y - self.robot_y)**2)
            
            # Si on est proche du point actuel, passer au suivant
            if distance < self.target_tolerance and i < len(self.planned_path) - 1:
                continue
                
            # Utiliser ce point comme cible
            self.current_target_index = i
            return (target_x, target_y), i
        
        # Si on arrive ici, on est proche du dernier point
        return self.planned_path[-1], len(self.planned_path) - 1
    
    def control_loop(self):
        """Contrôle avec stabilisation améliorée"""
        if not self.planned_path:
            return
            
        current_time = time.time()
        
        # Détecter si bloqué
        is_stuck = self.detect_if_stuck()
        
        # Décider si on doit replanifier (avec logique améliorée)
        if self.should_replan() and is_stuck:
            self.get_logger().warn('Replanification nécessaire...')
            new_path = self.plan_path()
            if new_path and len(new_path) > 1:
                # Vérifier que le nouveau chemin n'est pas trop différent
                if self.planned_path and len(self.planned_path) > self.current_target_index:
                    old_target = self.planned_path[self.current_target_index]
                    new_target = new_path[0]
                    
                    old_angle = math.atan2(old_target[1] - self.robot_y, old_target[0] - self.robot_x)
                    new_angle = math.atan2(new_target[1] - self.robot_y, new_target[0] - self.robot_x)
                    
                    angle_diff = abs(old_angle - new_angle)
                    angle_diff = min(angle_diff, 2*math.pi - angle_diff)
                    
                    if angle_diff < self.angle_change_threshold or self.consecutive_stuck_count >= self.force_replan_threshold:
                        self.planned_path = new_path
                        self.current_target_index = 0
                        self.path_creation_time = current_time
                        self.last_replan_time = current_time
                        self.publish_path()
                        self.stuck_counter = 0
                        self.consecutive_stuck_count = 0
                        self.avoidance_mode = False
                    else:
                        self.get_logger().info(f'Nouveau chemin trop différent ({angle_diff:.2f} rad), conservation du chemin actuel')
                else:
                    # Premier chemin ou pas de chemin actuel
                    self.planned_path = new_path
                    self.current_target_index = 0
                    self.path_creation_time = current_time
                    self.last_replan_time = current_time
                    self.publish_path()
            
        result = self.get_target_point()
        if not result:
            return
            
        (target_x, target_y), target_index = result
        
        cmd = Twist()
        
        # Calculer la distance et l'angle au target
        distance = math.sqrt((target_x - self.robot_x)**2 + (target_y - self.robot_y)**2)
        
        # Si très proche du dernier point, s'arrêter
        if distance < self.target_tolerance and target_index == len(self.planned_path) - 1:
            self.get_logger().info('Objectif final atteint!')
            self.cmd_pub.publish(Twist())
            self.planned_path = []
            self.avoidance_mode = False
            return
        
        # Calculer l'erreur d'angle
        angle_to_target = math.atan2(target_y - self.robot_y, target_x - self.robot_x)
        angle_error = angle_to_target - self.robot_yaw
        
        # Normaliser l'angle
        while angle_error > math.pi:
            angle_error -= 2 * math.pi
        while angle_error < -math.pi:
            angle_error += 2 * math.pi
        
        # Mémoriser l'angle cible pour éviter les changements brusques
        if self.last_target_angle is not None:
            angle_change = abs(angle_to_target - self.last_target_angle)
            angle_change = min(angle_change, 2*math.pi - angle_change)
            if angle_change > self.angle_change_threshold:
                # Limiter le changement d'angle
                angle_to_target = self.last_target_angle + np.sign(angle_error) * self.angle_change_threshold
        
        self.last_target_angle = angle_to_target
        
        # Détection d'obstacles
        obstacle_detected = False
        front_distance = float('inf')
        obstacle_threshold = self.total_robot_size + 0.3
        
        if self.current_scan:
            front_ranges = self.current_scan.ranges[len(self.current_scan.ranges)//2-15:len(self.current_scan.ranges)//2+15]
            valid_ranges = [r for r in front_ranges if not math.isinf(r) and r > 0]
            
            if valid_ranges:
                front_distance = min(valid_ranges)
                obstacle_detected = front_distance < obstacle_threshold
        
        # Machine à états pour évitement
        if obstacle_detected and not self.avoidance_mode:
            self.avoidance_mode = True
            self.avoidance_direction = self.choose_avoidance_direction()
            self.avoidance_start_time = current_time
            
        elif self.avoidance_mode:
            if (current_time - self.avoidance_start_time) > self.avoidance_timeout:
                self.avoidance_mode = False
            elif not obstacle_detected and abs(angle_error) < 0.5:
                self.avoidance_mode = False
        
        # Commandes de mouvement
        if self.avoidance_mode:
            cmd.linear.x = 0.15
            cmd.angular.z = 1.5 * self.avoidance_direction
        else:
            # Comportement normal avec vitesses lissées
            if abs(angle_error) > self.min_turn_angle:
                if abs(angle_error) > 0.4:
                    cmd.angular.z = np.sign(angle_error) * min(1.5, abs(angle_error) * 2.0)
                    cmd.linear.x = 0.1
                else:
                    cmd.angular.z = angle_error * 2.0
                    cmd.linear.x = min(0.5, distance * 2.0)
            else:
                cmd.linear.x = min(0.6, distance * 2.0)
                cmd.angular.z = angle_error * 0.8
        
        # Sécurité finale
        if front_distance < self.total_robot_size + 0.1:
            cmd.linear.x = 0.0
        
        self.cmd_pub.publish(cmd)

def main(args=None):
    rclpy.init(args=args)
    node = AStarPathfinder()
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
